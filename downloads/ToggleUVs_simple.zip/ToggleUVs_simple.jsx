var UVGroupName = "UVs"; 
	// creats variable. Change this name to whatever you call your layer set/group
var UVGroupLayer = app.activeDocument.layerSets.getByName(UVGroupName); 
	//defines variable of being in active document and finds layerset/group name based off of variable defined above
UVGroupLayer.visible = !UVGroupLayer.visible; 
	//toggles visiiblity of defined layer set/group 
